package com.example.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import java.util.*;

@Path("/apis")
public class employee{
static HashMap<String,String> users = new HashMap<String,String>();
@GET
@Path("/get")
@Produces("application/json")
public HashMap<String, String> getuser() {
	return users;
}                    

@PUT
@Path("{username}")
@Produces("application/json")
public String createCustomer(@PathParam("username") String name,String pass ) {
	users.put(name, pass);
    return "User name " + name+" and password is: "+pass ;
}

@POST
@Path("/changepass/{username}")
@Produces("application/json")
public String updateCustomer(@PathParam("username") String username,String pass) {
	if(users.get(username)==null) {
		return "User Not found";
	}
	users.put(username, pass);
    return "User name " + username+" and change password is: "+pass ;
}

@DELETE
@Path("/delete/{username}")
@Produces("application/json")
public String deleteCustomer(@PathParam("username") String username) {
	users.remove(username);
	 
    //return "User name " + username+" deleted";
	return "<html><p>User Name :"+username+" Deleted</p></html>";
}
}
