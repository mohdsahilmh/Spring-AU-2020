package com.example.demo;

import javax.websocket.server.PathParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

@Path("/apis/details")
public class putdetails {
	
	@POST
	@Produces("application/json")
	@Path("{id}")
	public String getuser(@PathParam("id") String id,String name) {
		return "id is:"+id+" name : " +name;
	}
}
